@echo off
chcp 65001 > nul
rem [회사명] 출근 런처 — 팀 창을 한 번에 연다
rem 팀이 늘면 아래 start 줄을 복사해 한 줄 추가한다

start "운영팀" cmd /k "cd /d %~dp001_운영팀 && claude"
start "영업팀" cmd /k "cd /d %~dp003_영업팀 && claude"
start "법무팀" cmd /k "cd /d %~dp002_법무팀 && claude"
start "네번째팀" cmd /k "cd /d %~dp004_[네 번째 팀] && claude"
