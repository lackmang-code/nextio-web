#!/bin/bash
# [회사명] 출근 런처 (Mac) — 터미널에서 chmod +x 시작.command 한 번 실행해 두세요
cd "$(dirname "$0")"
for T in 01_운영팀 03_영업팀 02_법무팀 "04_[네 번째 팀]"; do
  osascript -e "tell app \"Terminal\" to do script \"cd '$PWD/$T' && claude\""
done
